import torch

# input:tensor
# output:int/float
def get_entropy_of_dataset(tensor:torch.Tensor):
    """Calculate the entropy of the entire dataset"""
        # Extract the target_column
        # calculate entropy for a list of elements
        # identify unique classes in target column
   
        # calculate probabilty of each class element
        # find the entropy
    
    pass

# input:tensor,attribute number 
# output:int/float
def get_avg_info_of_attribute(tensor:torch.Tensor, attribute:int):
    """Return avg_info of the attribute provided as parameter"""
        # Extract the column with attribute being its index
        # identify unique elemnents in the column
        # extract the target column
        # Finding the entropy of each unique feature in the column by extracting them seperately
        # t1 contains column attributes which a unique in each iteration
        # t2 contains the corresponding target column which is mapped to the attribute column
        # Create new tensor
        # Calcuate average info of that attribute

    pass

# input:tensor,attribute number
# output:int/float
def get_information_gain(tensor:torch.Tensor, attribute:int):
    """Return Information Gain of the attribute provided as parameter"""
    # IG = Entropy - avg_information of atttribute
    pass

# input: tensor
# output: ({dict},int)
def get_selected_attribute(tensor:torch.Tensor):
    """
    Return a tuple with the first element as a dictionary which has IG of all columns
    and the second element as an integer representing attribute number of selected attribute

    example : ({0: 0.123, 1: 0.768, 2: 1.23} , 2)
    """
    
    # Create a dictionary of unique attribute mapped to its IG value
    # Traverse the dictionary and return the key corresponding to the max IG value
    

    pass